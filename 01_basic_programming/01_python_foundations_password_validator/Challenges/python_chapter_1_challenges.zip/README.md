# Chapter 1 Challenges

This repo contains the challenges for Chapter 1 of Python Foundations.

## Getting Started

1. Fork this repo to your account
2. Clone your forked repo to your machine
3. Refer to the [guidance on Journey](https://journey.makers.tech/pages/chapter-1-challenges) for further info
